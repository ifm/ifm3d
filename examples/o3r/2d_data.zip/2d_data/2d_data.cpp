/*
 * Copyright 2021-present ifm electronic, gmbh
 * SPDX-License-Identifier: Apache-2.0
 */
#include <iostream>
#include <ifm3d/camera/camera_o3r.h>
#include <ifm3d/fg.h>
#include <ifm3d/stlimage.h>
#include <ifm3d/fg/distance_image_info.h>
// #include <opencv2/core/core.hpp>
#if __has_include(<opencv2/core/core.hpp>)
#  include <opencv2/core/core.hpp>
#  include <opencv2/opencv.hpp>
#  include <opencv2/highgui.hpp>
#  define has_opencv 1
#else
#  define has_opencv 0
#endif
#include <typeinfo>

// LUT for image format conversion
static std::unordered_map<ifm3d::pixel_format, int> LUT_TYPE{
  {ifm3d::pixel_format::FORMAT_8U, CV_8U},
  {ifm3d::pixel_format::FORMAT_8S, CV_8S},
  {ifm3d::pixel_format::FORMAT_16U, CV_16U},
  {ifm3d::pixel_format::FORMAT_16S, CV_16S},
  {ifm3d::pixel_format::FORMAT_32S, CV_32S},
  {ifm3d::pixel_format::FORMAT_32F, CV_32F},
  {ifm3d::pixel_format::FORMAT_32F3, CV_32F},
  {ifm3d::pixel_format::FORMAT_64F, CV_64F}};
// LUT for image format size
static std::unordered_map<ifm3d::pixel_format, int> LUT_SIZE{
  {ifm3d::pixel_format::FORMAT_8U, 1},
  {ifm3d::pixel_format::FORMAT_8S, 1},
  {ifm3d::pixel_format::FORMAT_16U, 2},
  {ifm3d::pixel_format::FORMAT_16S, 2},
  {ifm3d::pixel_format::FORMAT_32S, 4},
  {ifm3d::pixel_format::FORMAT_32F, 4},
  {ifm3d::pixel_format::FORMAT_32F3, 4},
  {ifm3d::pixel_format::FORMAT_64F, 8}};

// Converts ifm3d::Image to cv:Mat.
// cv::Mat will not take ownership of the data.
// Make sure ifm3d::Image is not destroyed while the cv::Mat is still around.
cv::Mat ConvertImageToMatNoCopy(ifm3d::Image& img)
{
  return cv::Mat(img.height(), img.width(), LUT_TYPE[img.dataFormat()], img.ptr(0));
}

// Converts ifm3d::Image to cv:Mat.
// This function copies the data so that
// you can safely dispose of the ifm3d::Image.
cv::Mat ConvertImageToMatCopy(ifm3d::Image& img)
{
  auto mat = cv::Mat(img.height(), img.width(), LUT_TYPE[img.dataFormat()]);
  std::memcpy(mat.data, img.ptr(0), img.width()*img.height()*LUT_SIZE[img.dataFormat()]);
  return mat;
}

int main(){

    //////////////////////////
    // Declare the objects:
    //////////////////////////
    // Declare the device object (one object only, corresponding to the VPU)
    auto cam = std::make_shared<ifm3d::O3RCamera>();
    // Declare the FrameGrabber and ImageBuffer objects. 
    const auto PCIC_PORT = cam->Port("port0").pcic_port;
    auto fg = std::make_shared<ifm3d::FrameGrabber>(cam, ifm3d::DEFAULT_SCHEMA_MASK, PCIC_PORT);
    auto im =  std::make_shared<ifm3d::StlImageBuffer>(); 

    //////////////////////////
    // Get a frame:
    //////////////////////////
    if (! fg->WaitForFrame(im.get(), 3000))
    {
      std::cerr << "Timeout waiting for camera!" << std::endl;
      return -1;
    }
    
    //////////////////////////
    // Example for 2D data:
    //////////////////////////
    auto rgb_img = im->JPEGImage();

    if (has_opencv == 1){
      std::cout << "OpenCV is available" << std::endl;
      // No copy conversion of the image to cv::Mat:
      auto rgb_cv = ConvertImageToMatNoCopy(rgb_img);
      // Alternatively, use:
      // auto rgb_cv = ConvertImageToMatCopy(rgb_img);
      // Display the image
      cv::startWindowThread();
      cv::imshow("Distance", cv::imdecode(rgb_cv, cv::IMREAD_UNCHANGED));
      cv::waitKey(0);
    }
    else {
      std::cout << "OpenCV is not available, cannot display image." << std::endl;
    }

    return 0;
}