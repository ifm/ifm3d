# How to: receive and use the 2D rgb image

Receiving RGB data with ifm3d is done similarly as 3D data: the three core objects have to be instantiated, and a frame has to be retrieved (see full code below). 
The important part is how to access the RGB image and how to decode it for further use.

## Access the data
The RGB image is stored in JPEG format in the image buffer under the following name:
:::::{tabs}
::::{group-tab} Python
:::python
rgb_img = im.jpeg_image()
:::
::::
::::{group-tab} C++
:::cpp
auto rgb_img = im->JPEGImage();
:::
::::
:::::

## Decode the data
Once accessed, the RGB image has to be decoded:
:::::{tabs}
::::{group-tab} Python
:::python
rgb_decode = cv2.imdecode(rgb_img, cv2.IMREAD_UNCHANGED)
:::
::::
::::{group-tab} C++
:::cpp
auto rgb_decode = cv::imdecode(rgb_cv, cv::IMREAD_UNCHANGED);
:::
::::
:::::

## Display (optional)
The decoded image can then be displayed, for instance with OpenCV. 
> Note that in c++, the image first has to be converted to a cv::Mat.
> Follow the full example for the conversion to cv::Mat with or without copy.
:::::{tabs}
::::{group-tab} Python
:::python
cv2.imshow('title', rgb_decode)
cv2.waitKey(0)
cv2.destroyAllWindows()
:::
::::
::::{group-tab} C++
:::cpp
cv::startWindowThread();
cv::imshow("Distance", rgb_decode);
cv::waitKey(0);
:::
::::
:::::

## The full example
:::::{tabs}
::::{group-tab} Python
:::{literalinclude} 2d_data.py
:language: python
:::
::::

::::{group-tab} C++
:::{literalinclude} 2d_data.cpp
:language: cpp
:::
::::
:::::