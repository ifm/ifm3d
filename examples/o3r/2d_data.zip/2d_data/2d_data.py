from ifm3dpy import O3RCamera, ImageBuffer, FrameGrabber
import cv2
import time

# Initialize the objects
o3r = O3RCamera('192.168.0.69')
port = 'port0'
fg = FrameGrabber(o3r, pcic_port=50010)
im = ImageBuffer()
o3r.set({'ports':{port:{'state':'CONF'}}})
o3r.set({'ports':{port:{'state':'RUN'}}})
# Get a frame
if fg.wait_for_frame(im, 1000)==False:
    raise TimeoutError #Exception('fg-timeout on ' + port + ' reached')

# Read the distance image and display a pixel in the center
rgb = cv2.imdecode(im.jpeg_image(), cv2.IMREAD_UNCHANGED)
cv2.imshow('title', rgb)
cv2.waitKey(0)
cv2.destroyAllWindows()