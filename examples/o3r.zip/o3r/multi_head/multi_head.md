# How to: receive data from multiple heads
```{literalinclude} multi_head.cpp
:language: cpp
```